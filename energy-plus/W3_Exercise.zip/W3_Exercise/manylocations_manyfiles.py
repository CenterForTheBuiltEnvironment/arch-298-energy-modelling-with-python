"""run the file in many locations and output many files
it is easier to debiug when you have many file, 
in case you have an error in some of the files"""

from eppy.easyopen import easyopen
import ucb_helpers

fname = "model_base.idf"
wfile1 = "weather/CZ03RV2/CZ03RV2.epw"
wfile2 = "weather/CZ09RV2/CZ09RV2.epw"
wfile3 = "weather/CZ13RV2/CZ13RV2.epw"
# locations = [wfile1, wfile2, wfile3]

outfile1 = "loc1.idf"
outfile2 = "loc2.idf"
outfile3 = "loc3.idf"

idf = easyopen(fname) # we don't need a weather file, since we are not running them yet.
idf.saveas(outfile1)
idf.saveas(outfile2)
idf.saveas(outfile3)

# Now let us run these three files
idf1 = easyopen(outfile1, epw=wfile1)
idf2 = easyopen(outfile2, epw=wfile2)
idf3 = easyopen(outfile3, epw=wfile3)

ucb_helpers.eplaunch_run(idf1)
ucb_helpers.eplaunch_run(idf2)
ucb_helpers.eplaunch_run(idf3)

results = []
netsiteenergy1 = ucb_helpers.netsiteenergy(idf1)
results.append(netsiteenergy1)
netsiteenergy2 = ucb_helpers.netsiteenergy(idf2)
results.append(netsiteenergy2)
netsiteenergy3 = ucb_helpers.netsiteenergy(idf3)
results.append(netsiteenergy3)

print()
print(f"RESULTS = {results}")



