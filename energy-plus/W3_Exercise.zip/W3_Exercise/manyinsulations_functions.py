"""run the file with many insulations using a single file

refactor into functions
"""

from eppy.easyopen import easyopen
import ucb_helpers

def updateinsulation(idf, wallins=None, roofins=None, floorins=None):
    """change insulations"""
    surfaces = idf.idfobjects["BuildingSurface:Detailed"]
    roofs = [surface for surface in surfaces if surface.Surface_Type.upper() == "Roof".upper()]
    floors = [surface for surface in surfaces if surface.Surface_Type.upper() == "Floor".upper()]
    walls = [surface for surface in surfaces if surface.Surface_Type.upper() == "Wall".upper()]
    if wallins:
        for wall in walls:
            wall.Construction_Name = wallins
    if roofins:
        for roof in roofs:
            roof.Construction_Name = roofins
    if floorins:
        for floor in floors:
            floor.Construction_Name = floorins
    return idf
    
def run_getresults(idf):
    """run and get Net Site Energy reslts """
    ucb_helpers.eplaunch_run(idf)
    netsiteenergy = ucb_helpers.netsiteenergy(idf)
    return netsiteenergy

if __name__ == '__main__':
    fname = "model_base.idf"
    wfile = "weather/CZ03RV2/CZ03RV2.epw"
    idf = easyopen(fname, epw=wfile)

    results = []

    idf = updateinsulation(idf, "exterior wall R13", "roof R13", "ground floor R13")
    results.append(run_getresults(idf))

    idf = updateinsulation(idf, "exterior wall R19", "roof R19", "ground floor R19")
    results.append(run_getresults(idf))

    idf = updateinsulation(idf, "exterior wall R30", "roof R30", "ground floor R30")
    results.append(run_getresults(idf))


    print()
    print(f"RESULTS = {results}")


