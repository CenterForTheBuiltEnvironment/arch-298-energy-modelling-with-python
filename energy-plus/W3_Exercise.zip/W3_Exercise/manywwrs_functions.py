"""change the WWR of many simulation"""

from eppy.easyopen import easyopen
import ucb_helpers

def run_getresults(idf):
    """run and get Net Site Energy reslts """
    ucb_helpers.eplaunch_run(idf)
    netsiteenergy = ucb_helpers.netsiteenergy(idf)
    return netsiteenergy


def updatewindowlength(idf, length):
    """update the window length"""
    idf.idfobjects['WINDOW']
    winds = idf.idfobjects['WINDOW']
    wind = winds[0]
    wind.Length = length
    return idf
    

if __name__ == '__main__':
    fname = "model_base.idf"
    wfile = "weather/CZ03RV2/CZ03RV2.epw"
    idf = easyopen(fname, epw=wfile)


    results = []

    idf = updatewindowlength(idf, 1.5)
    results.append(run_getresults(idf))

    idf = updatewindowlength(idf, 3)
    results.append(run_getresults(idf))

    idf = updatewindowlength(idf, 6)
    results.append(run_getresults(idf))

    print()
    print(f"RESULTS = {results}")
