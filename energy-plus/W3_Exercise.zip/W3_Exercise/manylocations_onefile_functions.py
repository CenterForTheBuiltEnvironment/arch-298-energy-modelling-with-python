"""Refactor manylocations_onefile.py to use functions

run the file in many locations using a single file
it can be hard to debug if you have errors in some of 
your simulations, sine each simulation overwrites the
previous simulation

Use functions to do this"""

from eppy.easyopen import easyopen
import ucb_helpers

def run_getresults(idf, wfile):
    """run idf and return results"""
    idf.epw = wfile
    ucb_helpers.eplaunch_run(idf)
    netsiteenergy = ucb_helpers.netsiteenergy(idf)
    return netsiteenergy
    

if __name__ == '__main__':
    fname = "model_base.idf"
    wfile1 = "weather/CZ03RV2/CZ03RV2.epw"
    wfile2 = "weather/CZ09RV2/CZ09RV2.epw"
    wfile3 = "weather/CZ13RV2/CZ13RV2.epw"
    wfiles = [wfile1, wfile2, wfile3]


    idf = easyopen(fname, epw=None) 

    results = []
    for wfile in wfiles:
        result = run_getresults(idf, wfile)
        results.append(result)
    

    print()
    print(f"RESULTS = {results}")



