"""change the WWR of one imulation"""

from eppy.easyopen import easyopen
import ucb_helpers


fname = "model_base.idf"
wfile = "weather/CZ03RV2/CZ03RV2.epw"
idf = easyopen(fname, epw=wfile)

idf.idfobjects['WINDOW']
winds = idf.idfobjects['WINDOW']
wind = winds[0]
wind.Length = 1.5

idf.saveas("wwr10perc.idf")
ucb_helpers.eplaunch_run(idf)
netsiteenergy = ucb_helpers.netsiteenergy(idf)
print(netsiteenergy)

# compare model_base.idf and wwr10perc.idf - to see what has changed
# use idfdiff.py OR use winmerge.exe
