"""run the minimal file"""

from eppy.easyopen import easyopen

fname = "Minimal.idf"
wfile = "weather/CZ03RV2/CZ03RV2.epw"
idf = easyopen(fname, epw=wfile)
idf.run()

# the output files are called "eplusout.*"
# We would rather have it called by the file name
# in later scripts we will see ho to do this.

