"""change the WWR of many simulation"""

from eppy.easyopen import easyopen
import ucb_helpers


fname = "model_base.idf"
wfile = "weather/CZ03RV2/CZ03RV2.epw"
idf = easyopen(fname, epw=wfile)

idf.idfobjects['WINDOW']
winds = idf.idfobjects['WINDOW']
wind = winds[0]

results = []

wind.Length = 1.5
ucb_helpers.eplaunch_run(idf)
netsiteenergy = ucb_helpers.netsiteenergy(idf)
results.append(netsiteenergy)

wind.Length = 3
ucb_helpers.eplaunch_run(idf)
netsiteenergy = ucb_helpers.netsiteenergy(idf)
results.append(netsiteenergy)

wind.Length = 6
ucb_helpers.eplaunch_run(idf)
netsiteenergy = ucb_helpers.netsiteenergy(idf)
results.append(netsiteenergy)

print()
print(f"RESULTS = {results}")
