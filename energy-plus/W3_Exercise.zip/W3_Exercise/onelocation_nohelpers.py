"""Run one location without helper functions and extract the results"""

import os
from eppy.easyopen import easyopen
from eppy.results import readhtml


# from
# https://eppy.readthedocs.io/en/latest/runningeplus.html#Make-idf.run()-work-like-EPLaunch
def make_eplaunch_options(idf):
    """Make options for run, so that it runs like EPLaunch on Windows"""
    idfversion = idf.idfobjects['version'][0].Version_Identifier.split('.')
    idfversion.extend([0] * (3 - len(idfversion)))
    idfversionstr = '-'.join([str(item) for item in idfversion])
    fname = idf.idfname
    options = {
        # 'ep_version':idfversionstr, # runIDFs needs the version number
            # idf.run does not need the above arg
            # you can leave it there and it will be fine :-)
        'output_prefix':os.path.basename(fname).split('.')[0],
        'output_suffix':'C',
        'output_directory':os.path.dirname(fname),
        'readvars':True,
        'expandobjects':True
        }
    return options


fname = "model_base.idf"
wfile = "weather/CZ03RV2/CZ03RV2.epw"
idf = easyopen(fname, epw=wfile)

# from
# https://eppy.readthedocs.io/en/latest/runningeplus.html#Make-idf.run()-work-like-EPLaunch
theoptions = make_eplaunch_options(idf)
idf.run(**theoptions)

# replaced with 
# ucb_helpers.eplaunch_run(idf)

idf.idfname
idfname = idf.idfname
justname, ext = os.path.splitext(idfname)
htmname = f"{justname}Table.htm"

# from
# https://eppy.readthedocs.io/en/latest/Outputs_Tutorial.html#Using-titletable()-to-get-at-the-tables
htmhandle = open(htmname, 'r').read()
htables = readhtml.titletable(htmhandle)
netsiteenergy = htables[0][1][2][1]

# replaced with
# netsiteenergy = ucb_helpers.netsiteenergy(idf)
print(netsiteenergy)