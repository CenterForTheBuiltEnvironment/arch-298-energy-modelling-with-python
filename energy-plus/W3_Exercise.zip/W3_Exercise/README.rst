=============================
List of scripts for UCB class
=============================

Start with the first script and work you way through each number, from 1 to 15. Scripts for D, E, F, G, H have not been written. It is left as an exercise for you.

Also you can try to do the Bonus Script at the end.

Look into parametric_simulation_matrix.xlsx to see the basis of the parametrics below

Initial scripts
===============

1. openprintminimalfile.py
2. editminimalfile.py
3. runminimal.py


scripts to run parametric
=========================

A. Location script
    4. onelocation_nohelpers.py
    5. manylocation_onefile.py
    6. manylocations_manyfiles.py
    7. manylocations_onefile_functions.py
B. Wall insulation script
    8. oneinsulations.py
    9. manyinsulations.py
    10. manyinsulations_functions.py
C. WWR script
    11. onewwr.py
    12. manywwrs.py
    13. manywwrs_functions.py
D. SHGC script
    - glass = idf.getobject("WindowMaterial:Glazing", "CLEAR 6MM")
        - change glass.Solar_Transmittance_at_Normal_Incidence
    - alternative is make new glass for each of the SHGC 
        - this may be better
E. infiltration script
    - infil = idf.getobject("ZoneInfiltration:DesignFlowRate", "infiltration")
        - change infil.Air_Changes_per_Hour
F. Occ. Dens. script
    - people = idf.getobject("People", "PPL")
        - change people.People_per_Floor_Area
G. Equip. Lighting script
    - lights = idf.getobject("Lights", "Lights09")
        - change lights.Watts_per_Floor_Area
    - equip = idf.getobject("ElectricEquipment", "Equip")
        - change equip.Watts_per_Floor_Area
H. Thermostat script
     - coolingsetpoint = idf.getobject("Schedule:Compact", "Cooling Setpoint")
         - change coolingsetpoint.Field_6

Comination scripts
==================

- Wall insulation + wwr
    14. ins_wwr.py
    15. ins_wwr_loops.py

imports
=======

- ucb_helpers



To find differences between idf files
=====================================

idfdiff.py -> from eppy/usefulscripts

usage::

    python idfdiff.py --csv file1.idf file2.idf > diff.csv
    open and lookat diff.csv

Bonus scripts
=============

- Look at model_start.idf and model_base.idf. 
- Can you modify model_start.idf to model_base.idf using just eppy?
- You may need to use idf.newidfobject() and maybe idf.removeidfobject