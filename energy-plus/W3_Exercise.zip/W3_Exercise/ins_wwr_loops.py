"""Combine Insulation and WWR as parameters"""

from eppy.easyopen import easyopen
import ucb_helpers

from manyinsulations_functions import updateinsulation
from manywwrs_functions import updatewindowlength

def run_getresults(idf):
    """run and get Net Site Energy reslts """
    ucb_helpers.eplaunch_run(idf)
    netsiteenergy = ucb_helpers.netsiteenergy(idf)
    return netsiteenergy
    
fname = "model_base.idf"
wfile = "weather/CZ03RV2/CZ03RV2.epw"
idf = easyopen(fname, epw=wfile)

results = []


# insulations
args13 = "exterior wall R13", "roof R13", "ground floor R13"
args19 = "exterior wall R19", "roof R19", "ground floor R19"
args30 = "exterior wall R30", "roof R30", "ground floor R30"

for args in [args13, args19, args30]:
    idf = updateinsulation(idf, *args)
    for length in [1.5, 3, 6]:
        # wwrs
        idf = updatewindowlength(idf, length)
        results.append(run_getresults(idf))
        


print()
print(f"RESULTS = {results}")
