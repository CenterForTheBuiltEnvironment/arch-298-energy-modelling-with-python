"""open and print the Minimal.idf"""

from eppy.easyopen import easyopen

fname = "Minimal.idf"
idf = easyopen(fname)
idf.printidf()