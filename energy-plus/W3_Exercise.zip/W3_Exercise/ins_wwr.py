"""Combine Insulation and WWR as parameters"""

from eppy.easyopen import easyopen
import ucb_helpers

from manyinsulations_functions import updateinsulation
from manywwrs_functions import updatewindowlength

def run_getresults(idf):
    """run and get Net Site Energy reslts """
    ucb_helpers.eplaunch_run(idf)
    netsiteenergy = ucb_helpers.netsiteenergy(idf)
    return netsiteenergy
    
fname = "model_base.idf"
wfile = "weather/CZ03RV2/CZ03RV2.epw"
idf = easyopen(fname, epw=wfile)

results = []


# Set insulation
idf = updateinsulation(idf, "exterior wall R13", "roof R13", "ground floor R13")

# set wwrs
idf = updatewindowlength(idf, 1.5)
results.append(run_getresults(idf))
idf = updatewindowlength(idf, 3)
results.append(run_getresults(idf))
idf = updatewindowlength(idf, 6)
results.append(run_getresults(idf))


# Set insulation
idf = updateinsulation(idf, "exterior wall R19", "roof R19", "ground floor R19")

# set wwrs
idf = updatewindowlength(idf, 1.5)
results.append(run_getresults(idf))
idf = updatewindowlength(idf, 3)
results.append(run_getresults(idf))
idf = updatewindowlength(idf, 6)
results.append(run_getresults(idf))


# Set insulation
idf = updateinsulation(idf, "exterior wall R30", "roof R30", "ground floor R30")

# set wwrs
idf = updatewindowlength(idf, 1.5)
results.append(run_getresults(idf))
idf = updatewindowlength(idf, 3)
results.append(run_getresults(idf))
idf = updatewindowlength(idf, 6)
results.append(run_getresults(idf))

print()
print(f"RESULTS = {results}")
