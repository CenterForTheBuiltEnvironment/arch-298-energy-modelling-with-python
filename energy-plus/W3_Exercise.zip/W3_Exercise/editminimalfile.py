"""edit the Minimal.idf"""

from eppy.easyopen import easyopen

fname = "Minimal.idf"
idf = easyopen(fname)

buildings = idf.idfobjects["BUILDING"]
print(buildings)
building = buildings[0]
print(building)
building.Name = "Taj Mahal"
idf.saveas("TajMahal.idf")

# open Minimal.idf and TajMahal.idf and look at the Building Name

