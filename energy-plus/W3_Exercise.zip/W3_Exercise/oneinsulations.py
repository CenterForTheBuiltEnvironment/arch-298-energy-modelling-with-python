"""run the file with many insulations using a single file
Sav the file to see what has changed
"""

from eppy.easyopen import easyopen
import ucb_helpers

fname = "model_base.idf"
wfile = "weather/CZ03RV2/CZ03RV2.epw"
idf = easyopen(fname, epw=wfile)


surfaces = idf.idfobjects["BuildingSurface:Detailed"]
roofs = [surface for surface in surfaces if surface.Surface_Type.upper() == "Roof".upper()]
floors = [surface for surface in surfaces if surface.Surface_Type.upper() == "Floor".upper()]
walls = [surface for surface in surfaces if surface.Surface_Type.upper() == "Wall".upper()]

for wall in walls:
    wall.Construction_Name = "exterior wall R13"
for roof in roofs:
    roof.Construction_Name = "roof R13"
for floor in floors:
    floor.Construction_Name = "ground floor R13"

idf.saveas("R13.idf")
ucb_helpers.eplaunch_run(idf)
netsiteenergy = ucb_helpers.netsiteenergy(idf)
print(netsiteenergy)

# compare model_base.idf and R13.idf - to see what has changed
# use idfdiff.py OR use winmerge.exe