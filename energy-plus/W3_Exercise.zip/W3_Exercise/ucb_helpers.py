"""Dome helper functions for the UCB Course"""

import os
from eppy.modeleditor import IDF
from eppy.runner.run_functions import runIDFs
from eppy.results import readhtml


def make_eplaunch_options(idf):
    """Make options for run, so that it runs like EPLaunch on Windows"""
    idfversion = idf.idfobjects['version'][0].Version_Identifier.split('.')
    idfversion.extend([0] * (3 - len(idfversion)))
    idfversionstr = '-'.join([str(item) for item in idfversion])
    fname = idf.idfname
    options = {
        # 'ep_version':idfversionstr, # runIDFs needs the version number
            # idf.run does not need the above arg
            # you can leave it there and it will be fine :-)
        'output_prefix':os.path.basename(fname).split('.')[0],
        'output_suffix':'C',
        'output_directory':os.path.dirname(fname),
        'readvars':True,
        'expandobjects':True
        }
    return options

def eplaunch_run(idf):
    """run the idf with the default eplaunch settings"""
    theoptions = make_eplaunch_options(idf)
    idf.run(**theoptions)

def htmltables(idf):
    """read the html of the idf file"""
    idf.idfname
    idfname = idf.idfname
    justname, ext = os.path.splitext(idfname)
    htmname = f"{justname}Table.htm"
    htmhandle = open(htmname, 'r').read()
    htables = readhtml.titletable(htmhandle)
    return htables
    
def netsiteenergy(idf):
    """return the net Site Energy"""
    htables = htmltables(idf)
    netsiteenergy = htables[0][1][2][1]
    return netsiteenergy

def objectsinidf(idf):
    """Return the keys of all idfobjects that have more than one intem"""
    return [key for key in idf.idfobjects.keys() if idf.idfobjects[key]]
